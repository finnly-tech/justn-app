package com.mobileapp.justn.network;


public interface IResult
{
    public void notifyResult(String result);
}
