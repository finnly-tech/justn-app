package com.mobileapp.justn.model;

import com.kwabenaberko.newsapilib.models.Source;

public class Sources
{
    Source source;
    boolean blocked=false;

    public Source getSource() {
        return source;
    }

    public void setSource(Source source) {
        this.source = source;
    }

    public boolean isBlocked() {
        return blocked;
    }

    public void setBlocked(boolean blocked) {
        this.blocked = blocked;
    }

}
