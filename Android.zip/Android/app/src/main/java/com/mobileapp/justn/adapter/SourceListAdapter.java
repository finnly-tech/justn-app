package com.mobileapp.justn.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.kwabenaberko.newsapilib.models.Article;
import com.mobileapp.justn.R;
import com.mobileapp.justn.model.Sources;
import com.squareup.picasso.Picasso;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class SourceListAdapter extends RecyclerView.Adapter<SourceListAdapter.ViewHolder>
{
    private List<Sources> dataList=new ArrayList<>();
    Context mContext;
    private OnItemClickListener onItemClickListener;
    Picasso picasso;

    public interface OnItemClickListener
    {
        void onItemClick(int position);
    }
    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public List<Sources> getDataList() {
        return dataList;
    }

    public SourceListAdapter(Context context, List<Sources> eventList)
    {
        this.dataList.addAll(eventList);
        mContext=context;
        picasso=Picasso.get();
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item_source, parent, false);
        return new ViewHolder(view);
    }
    @Override
    public int getItemCount()
    {
        return dataList == null? 0: dataList.size();
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position)
    {
        final Sources item = dataList.get(position);
        holder.setDetails(item,position);
    }

    public void updateList(List<Sources> items)
    {
        final DiffCallback diffCallback = new DiffCallback(this.dataList, items);
        final DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);
        this.dataList.clear();
        this.dataList.addAll(items);
        diffResult.dispatchUpdatesTo(this);
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
        private TextView tvTitle;
        private ImageView imageBlock;

        public ViewHolder(View itemView)
        {
            super(itemView);
            tvTitle=itemView.findViewById(R.id.tv_heading);
            imageBlock=itemView.findViewById(R.id.img_block);
            itemView.setOnClickListener(this);
        }

        public void setDetails(final Sources item,int pos)
        {
            tvTitle.setText(item.getSource().getName());

            if(item.isBlocked())
            {
                imageBlock.setImageResource(R.drawable.img_block);
            }
            else
            {
                imageBlock.setImageResource(R.drawable.ic_circle);
            }
        }

        @Override
        public void onClick(View v) {
            if (onItemClickListener != null)
                onItemClickListener.onItemClick(getAdapterPosition());
        }
    }

    public static class DiffCallback extends DiffUtil.Callback
    {
        private List<Sources> mOldList;
        private List<Sources> mNewList;

        public DiffCallback(List<Sources> oldList, List<Sources> newList) {
            this.mOldList = oldList;
            this.mNewList = newList;
        }
        @Override
        public int getOldListSize() {
            return mOldList.size();
        }

        @Override
        public int getNewListSize() {
            return mNewList.size();
        }

        @Override
        public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
            // add a unique ID property on Contact and expose a getId() method
            return mOldList.get(oldItemPosition).getSource().getId() .equalsIgnoreCase(mNewList.get(newItemPosition).getSource().getId());
        }

        @Override
        public boolean areContentsTheSame(int oldItemPosition, int newItemPosition)
        {
            Sources oldContact = mOldList.get(oldItemPosition);
            Sources newContact = mNewList.get(newItemPosition);
            return oldContact.isBlocked()==newContact.isBlocked();
        }
    }

}


