package com.mobileapp.justn.network;

public class APIList
{
   public static String GET_ALERTS="https://ndmaalert.maxmindsolution.com/api/AlertManagement/getAlerts";
   public static String LOGIN="https://ndmaalert.maxmindsolution.com/api/login";
   public static String GET_ADVISORIES="http://182.191.84.176/ndma/public/api/AllAdvisory";
}
