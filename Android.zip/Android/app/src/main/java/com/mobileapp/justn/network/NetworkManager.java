package com.mobileapp.justn.network;

import android.content.Context;
import android.os.Handler;
import android.util.Log;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.CacheControl;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;


public class NetworkManager
{
    public static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    private static NetworkManager instance = null;
    OkHttpClient client;
    Context mContext;
    Handler mainHandler;

    String token="";
    public OkHttpClient getClient() {
        return client;
    }


    public void setToken(String token) {
        this.token = token;
    }

    private NetworkManager(Context context)
    {
        client=new OkHttpClient.Builder()
                .addInterceptor(new HttpLoggingInterceptor())
                .connectTimeout(120, TimeUnit.SECONDS)
                .writeTimeout(120, TimeUnit.SECONDS)
                .readTimeout(120, TimeUnit.SECONDS).cache(null).build();
        mContext=context;
        mainHandler = new Handler(context.getMainLooper());
    }


    public void loginRequest(String url, HashMap<String,Object> params, IResult result)
    {
        FormBody.Builder builder=new FormBody.Builder();
        for ( Map.Entry<String, Object> entry : params.entrySet())
        {
            builder.add(entry.getKey(), entry.getValue().toString());
        }

        RequestBody body = builder.build();
        Request request = new Request.Builder().url(url).post(body)
                .cacheControl(CacheControl.FORCE_NETWORK).build();
        Call call = client.newCall(request);
        call.enqueue(new Callback()
        {
            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException
            {
                String jsonData = response.body().string();
                Log.i("responseAPI",jsonData);
                mainHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        result.notifyResult(jsonData);
                    }
                });
            }
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e)
            {

            }
        });
    }


    public void postRequest(String url, HashMap<String,Object> params, IResult result)
    {
        FormBody.Builder builder=new FormBody.Builder();
        for ( Map.Entry<String, Object> entry : params.entrySet())
        {
            builder.add(entry.getKey(), entry.getValue().toString());
        }

        RequestBody body = builder.build();
        Request request = new Request.Builder().addHeader("Authorization", "bearer "+token).url(url).post(body)
                .cacheControl(CacheControl.FORCE_NETWORK).build();
        Call call = client.newCall(request);
        call.enqueue(new Callback()
        {
            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException
            {
                String jsonData = response.body().string();
                Log.i("responseAPI",jsonData);
                mainHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        result.notifyResult(jsonData);
                    }
                });
            }
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e)
            {

            }
        });
    }

    public void getRequest(String url, IResult result)
    {

        Request request = new Request.Builder().addHeader("Authorization", "bearer "+token).url(url)
                .cacheControl(CacheControl.FORCE_NETWORK).build();
        Call call = client.newCall(request);
        call.enqueue(new Callback()
        {
            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException
            {
                String jsonData = response.body().string();
                Log.i("responseAPI",jsonData);
                mainHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        result.notifyResult(jsonData);
                    }
                });
            }
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e)
            {

            }
        });
    }

    public void getAdvisories(IResult result)
    {

        Request request = new Request.Builder()
                //.url("http://182.191.84.176/ndma/public/api/AllAdvisory")
                .url("http://www.ndma.gov.pk/api/AllAdvisory")
                .addHeader("Authorization", "Bearer 6|8wkzP6Qt8cVWWDrIJa8roqc9KC0KBbbgRLyEbCm13744629c")
                .build();

        Call call = client.newCall(request);
        call.enqueue(new Callback()
        {
            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException
            {
                String jsonData = response.body().string();
                Log.i("responseAPI",jsonData);
                mainHandler.post(new Runnable()
                {
                    @Override
                    public void run()
                    {
                        result.notifyResult(jsonData);
                    }
                });

            }
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e)
            {

            }
        });
    }



    public static synchronized NetworkManager getInstance(Context context)
    {
        if (instance == null) {
            instance = new NetworkManager(context);
        }
        return instance;
    }
}
