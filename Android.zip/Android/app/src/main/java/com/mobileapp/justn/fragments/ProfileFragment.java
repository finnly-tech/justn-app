package com.mobileapp.justn.fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.mobileapp.justn.AccountSettings;
import com.mobileapp.justn.HidePublishersActivity;
import com.mobileapp.justn.LoginActivity;
import com.mobileapp.justn.NotificationsActivity;
import com.mobileapp.justn.R;
import com.mobileapp.justn.data.DataManager;

public class ProfileFragment extends Fragment
{
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =inflater.inflate(R.layout.fragment_profile, container, false);
        TextView tvNotifications=view.findViewById(R.id.tv_notifications);
        TextView tvHidePublishers=view.findViewById(R.id.tv_hide_publishers);
        TextView tvLegal=view.findViewById(R.id.tv_legal);
        TextView tvSignout=view.findViewById(R.id.tv_signout);
        TextView tvSettings=view.findViewById(R.id.tv_settings);
        tvSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(),AccountSettings.class));
                Animatoo.INSTANCE.animateSlideLeft(getContext());
            }
        });
        DataManager manager=DataManager.getInstance(getContext());
        tvSignout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                new AlertDialog.Builder(getContext())
                        .setTitle("Logout")
                        .setMessage("Are you sure you want to logout?")
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int which)
                            {
                                manager.setLoginstatus(false);
                                getActivity().finish();
                                startActivity(new Intent(getContext(), LoginActivity.class));
                                Animatoo.INSTANCE.animateSlideRight(getContext());
                            }
                        })
                        .setNegativeButton(android.R.string.no, null)
                        .show();
            }
        });
        tvLegal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.justn.xyz/legal"));
                startActivity(browserIntent);
            }
        });
        tvHidePublishers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), HidePublishersActivity.class));
                Animatoo.INSTANCE.animateSlideLeft(getContext());
            }
        });
        tvNotifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), NotificationsActivity.class));
                Animatoo.INSTANCE.animateSlideLeft(getContext());
            }
        });
        return  view;
    }
}