package com.mobileapp.justn;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.google.gson.Gson;
import com.mobileapp.justn.data.DataManager;
import com.mobileapp.justn.model.User;
import com.mobileapp.justn.utils.AlarmReceiver;

import java.util.Calendar;

public class AccountSettings extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        DataManager manager=DataManager.getInstance(this);
        Gson gson=new Gson();
        User user=gson.fromJson(manager.getUserdetails(),User.class);
        setContentView(R.layout.activity_account_settings);
        SwitchCompat notificationSwitch=findViewById(R.id.switch_notification);
        SwitchCompat modeSwitch=findViewById(R.id.swith_mode);
        notificationSwitch.setChecked(user.isNotification());
        modeSwitch.setChecked(user.isLightmode());
        notificationSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b)
            {
                if(b)
                {
                    setNotificationAlert();
                }
                user.setNotification(b);
                manager.setUserdetails(gson.toJson(user));
            }
        });
        modeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isNightModeOn)
            {
                user.setLightmode(isNightModeOn);
                manager.setUserdetails(gson.toJson(user));
            }
        });
        ImageView imgBack=findViewById(R.id.img_back);
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                Animatoo.INSTANCE.animateSlideRight(AccountSettings.this);
            }
        });
    }

    public void setNotificationAlert()
    {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 17);
        calendar.set(Calendar.MINUTE,0);
        calendar.set(Calendar.SECOND, 0);
        Intent intent1 = new Intent(AccountSettings.this, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(AccountSettings.this, 0,intent1, PendingIntent.FLAG_MUTABLE);
        AlarmManager am = (AlarmManager) AccountSettings.this.getSystemService(AccountSettings.this.ALARM_SERVICE);
        am.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pendingIntent);
    }

}