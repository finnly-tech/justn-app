package com.mobileapp.justn.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.kwabenaberko.newsapilib.NewsApiClient;
import com.kwabenaberko.newsapilib.models.Article;
import com.kwabenaberko.newsapilib.models.request.EverythingRequest;
import com.kwabenaberko.newsapilib.models.request.TopHeadlinesRequest;
import com.kwabenaberko.newsapilib.models.response.ArticleResponse;
import com.mobileapp.justn.MainActivity;
import com.mobileapp.justn.NewsDetails;
import com.mobileapp.justn.R;
import com.mobileapp.justn.adapter.ArticleListAdapter;
import com.mobileapp.justn.adapter.HeadlineListAdapter;
import com.mobileapp.justn.data.DataManager;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class TopStoriesFragment extends Fragment {

    List<String>blocklist=new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_top_stories, container, false);
        RecyclerView recyclerView=view.findViewById(R.id.data_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        List<Article> articles=new ArrayList<>();
        ProgressBar progressBar=view.findViewById(R.id.progress_circular);
        HeadlineListAdapter adapter=new HeadlineListAdapter(getContext(),articles);
        recyclerView.setAdapter(adapter);
        TextView tvFeed=view.findViewById(R.id.tv_feed);
        loadData(adapter,progressBar);
        tvFeed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                recyclerView.smoothScrollToPosition(0);
            }
        });
        return view;
    }

    public void loadData(HeadlineListAdapter adapter,ProgressBar progressBar)
    {

        DataManager manager=DataManager.getInstance(getContext());
        Gson gson = new Gson();
        if(!manager.getBlockList().isEmpty())
        {
            Type type = new TypeToken<ArrayList<String>>() {}.getType();
            blocklist =gson.fromJson(manager.getBlockList(), type);
        }

        NewsApiClient newsApiClient = new NewsApiClient("7b68afae74bb4e3bb788bd03def3cac2");
        progressBar.setVisibility(View.VISIBLE);
        newsApiClient.getTopHeadlines(new TopHeadlinesRequest.Builder().country("us").language("en").build(),
                new NewsApiClient.ArticlesResponseCallback() {
            @Override
            public void onSuccess(ArticleResponse response)
            {
                progressBar.setVisibility(View.GONE);

                List<Article>articles=new ArrayList<>();
                for(Article article:response.getArticles())
                {
                    if(article.getUrlToImage()!=null&&!article.getUrlToImage().isEmpty()&&!blocklist.contains(article.getSource().getName()))
                    {
                        articles.add(article);
                    }
                }
                adapter.updateList(articles);
            }

            @Override
            public void onFailure(Throwable throwable)
            {
                progressBar.setVisibility(View.GONE);
                System.out.println(throwable.getMessage());
            }
        });

        adapter.setOnItemClickListener(new HeadlineListAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position)
            {
                if(!adapter.getDataList().get(position).getUrl().isEmpty())
                {
                    String link=adapter.getDataList().get(position).getUrl();
                    startActivity(new Intent(getContext(), NewsDetails.class).putExtra("link",link));
                }
            }
        });

    }
}