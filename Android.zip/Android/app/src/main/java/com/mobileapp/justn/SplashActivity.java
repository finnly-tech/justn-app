package com.mobileapp.justn;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.mobileapp.justn.data.DataManager;

import java.util.Timer;
import java.util.TimerTask;

@SuppressLint("CustomSplashScreen")
public class SplashActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        DataManager manager=DataManager.getInstance(this);

        TimerTask task = new TimerTask()
        {
            @Override
            public void run()
            {
                if(!manager.getLoginStatus())
                {
                    Intent i = new Intent(SplashActivity.this,LoginActivity.class);
                    startActivity(i);
                }
                else
                {
                    Intent i = new Intent(SplashActivity.this,MainActivity.class);
                    startActivity(i);
                }

                Animatoo.INSTANCE.animateSlideLeft(SplashActivity.this);
                finish();
            }
        };

        new Timer().schedule(task, 3000);
    }
}