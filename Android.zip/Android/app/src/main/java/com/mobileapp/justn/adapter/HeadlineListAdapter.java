package com.mobileapp.justn.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.kwabenaberko.newsapilib.models.Article;
import com.mobileapp.justn.R;
import com.mobileapp.justn.utils.Constants;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class HeadlineListAdapter extends RecyclerView.Adapter<HeadlineListAdapter.ViewHolder>
{
    private  int TYPE_HEADER = 0;
    private List<Article> dataList=new ArrayList<>();
    Context mContext;
    private OnItemClickListener onItemClickListener;
    Picasso picasso;

    public interface OnItemClickListener
    {
        void onItemClick(int position);
    }
    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public List<Article> getDataList() {
        return dataList;
    }

    public HeadlineListAdapter(Context context, List<Article> eventList)
    {
        this.dataList.addAll(eventList);
        mContext=context;
        picasso=Picasso.get();
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view;
        if(viewType==TYPE_HEADER)
        {
            view = layoutInflater.inflate(R.layout.item_headline_header, parent, false);
        }
        else
        {
            view = layoutInflater.inflate(R.layout.item_headline, parent, false);
        }

        return new ViewHolder(view);
    }
    @Override
    public int getItemCount()
    {
        return dataList == null? 0: dataList.size();
    }

    @Override
    public int getItemViewType(int position)
    {
        return position;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position)
    {
        final Article item = dataList.get(position);
        holder.setDetails(item,position);
    }

    public void updateList(List<Article> items)
    {
        final DiffCallback diffCallback = new DiffCallback(this.dataList, items);
        final DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);
        this.dataList.clear();
        this.dataList.addAll(items);
        diffResult.dispatchUpdatesTo(this);
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
        private ImageView mPostImage;
        private TextView tvTitle;

        public ViewHolder(View itemView)
        {
            super(itemView);
            mPostImage=itemView.findViewById(R.id.img_post);
            tvTitle=itemView.findViewById(R.id.tv_heading);
            itemView.setOnClickListener(this);
        }

        public void setDetails(final Article item,int pos)
        {
            tvTitle.setText(item.getTitle());
            if(item.getUrlToImage()!=null&&!item.getUrlToImage().isEmpty())
            {
                mPostImage.setVisibility(View.VISIBLE);
                picasso.load(item.getUrlToImage()).fit().into(mPostImage);
            }

            else mPostImage.setVisibility(View.GONE);
            //ZonedDateTime dateTime  = ZonedDateTime.parse(item.getPublishedAt());
            //tvDate.setText(DateTimeFormatter.ofPattern("dd-MM-yyyy  hh:mm a").format(dateTime));
            //tvDesc.setText(item.getDescription());
        }

        @Override
        public void onClick(View v) {
            if (onItemClickListener != null)
                onItemClickListener.onItemClick(getAdapterPosition());
        }

    }



    public static class DiffCallback extends DiffUtil.Callback
    {
        private List<Article> mOldList;
        private List<Article> mNewList;

        public DiffCallback(List<Article> oldList, List<Article> newList) {
            this.mOldList = oldList;
            this.mNewList = newList;
        }
        @Override
        public int getOldListSize() {
            return mOldList.size();
        }

        @Override
        public int getNewListSize() {
            return mNewList.size();
        }

        @Override
        public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
            // add a unique ID property on Contact and expose a getId() method
            return mOldList.get(oldItemPosition).getContent() .equalsIgnoreCase(mNewList.get(newItemPosition).getContent());
        }

        @Override
        public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
            Article oldContact = mOldList.get(oldItemPosition);
            Article newContact = mNewList.get(newItemPosition);
            return oldContact.getTitle().equalsIgnoreCase(newContact.getTitle());
        }
    }





}


