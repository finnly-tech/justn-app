package com.mobileapp.justn;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.kwabenaberko.newsapilib.NewsApiClient;
import com.kwabenaberko.newsapilib.models.Source;
import com.kwabenaberko.newsapilib.models.request.EverythingRequest;
import com.kwabenaberko.newsapilib.models.request.SourcesRequest;
import com.kwabenaberko.newsapilib.models.response.ArticleResponse;
import com.kwabenaberko.newsapilib.models.response.SourcesResponse;
import com.mobileapp.justn.adapter.SourceListAdapter;
import com.mobileapp.justn.data.DataManager;
import com.mobileapp.justn.model.Sources;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class HidePublishersActivity extends AppCompatActivity
{
    List<String>blocklist=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hide_publishers);
        RecyclerView recyclerView=findViewById(R.id.data_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        ProgressBar progressBar=findViewById(R.id.progress_circular);
        NewsApiClient newsApiClient = new NewsApiClient("7b68afae74bb4e3bb788bd03def3cac2");
        progressBar.setVisibility(View.VISIBLE);
        List<Sources>sources=new ArrayList<>();
        DataManager manager=DataManager.getInstance(this);
        Gson gson = new Gson();
        if(!manager.getBlockList().isEmpty())
        {
           Type type = new TypeToken<ArrayList<String>>() {}.getType();
           blocklist =gson.fromJson(manager.getBlockList(), type);
        }

        SourceListAdapter adapter=new SourceListAdapter(getBaseContext(),sources);
        recyclerView.setAdapter(adapter);
        progressBar.setVisibility(View.VISIBLE);
        newsApiClient.getSources(
                new SourcesRequest.Builder()
                        .language("en")
                        .build(),
                new NewsApiClient.SourcesCallback() {
                    @Override
                    public void onSuccess(SourcesResponse response)
                    {
                        sources.clear();
                        progressBar.setVisibility(View.GONE);

                        for(int i=0;i<response.getSources().size();i++)
                        {
                            Source source=response.getSources().get(i);
                            Sources item=new Sources();
                            item.setSource(source);

                            if(blocklist.contains(item.getSource().getName()))
                            {
                                item.setBlocked(true);
                            }
                            else
                            {
                                item.setBlocked(false);
                            }
                            sources.add(item);
                        }
                        adapter.updateList(sources);

                        adapter.setOnItemClickListener(new SourceListAdapter.OnItemClickListener() {
                            @Override
                            public void onItemClick(int position)
                            {
                                Sources item=sources.get(position);
                                item.setBlocked(!item.isBlocked());
                                adapter.updateList(sources);
                                adapter.notifyDataSetChanged();
                            }
                        });


                    }

                    @Override
                    public void onFailure(Throwable throwable)
                    {
                        progressBar.setVisibility(View.GONE);
                        System.out.println(throwable.getMessage());
                    }
                }
        );



        ImageView imgBack=findViewById(R.id.img_back);
        imgBack.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                List<String>list=new ArrayList<>();
                for(Sources item:adapter.getDataList())
                {
                    if(item.isBlocked())
                    {
                        list.add(item.getSource().getName());
                    }
                }
                manager.setBlockList(new Gson().toJson(list));
                finish();
                Animatoo.INSTANCE.animateSlideRight(HidePublishersActivity.this);
            }
        });
    }
}