package com.mobileapp.justn.data;

import android.content.Context;
import android.content.SharedPreferences;


public class DataManager
{
    Context mContext;
    private static DataManager instance = null;

    private SharedPreferences pref;
    private static final String PREF_NAME = "justN";
    private static final String BLOCKLIST = "blockList";
    private static final String USERDETAILS = "userDetails";
    private static final String LOGINSTATUS= "loginStatus";
    private SharedPreferences.Editor editor;
    private int PRIVATE_MODE = 0;

    private DataManager(Context context)
    {
        mContext=context;
        pref = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public static synchronized DataManager getInstance(Context context)
    {
        if (instance == null) {
            instance = new DataManager(context);
        }
        return instance;
    }

    public void setLoginstatus(boolean val)
    {
        editor.putBoolean(LOGINSTATUS,val);
        editor.apply();
    }

    public boolean getLoginStatus()
    {
        return pref.getBoolean(LOGINSTATUS,false);
    }

    public void setUserdetails(String userdetails)
    {
        editor.putString(USERDETAILS,userdetails);
        editor.apply();
    }

    public String getUserdetails()
    {
        return pref.getString(USERDETAILS,"");
    }

    public void setBlockList(String list)
    {
        editor.putString(BLOCKLIST,list);
        editor.apply();
    }

    public String getBlockList()
    {
      return pref.getString(BLOCKLIST,"");
    }
}
