package com.mobileapp.justn;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.mobileapp.justn.data.DataManager;
import com.mobileapp.justn.model.User;
import com.mobileapp.justn.utils.Constants;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        TextView tvLogin=findViewById(R.id.tv_login);
        EditText etEmail=findViewById(R.id.et_email);
        EditText etPassword=findViewById(R.id.et_pass);
        MaterialButton registerButton=findViewById(R.id.button_progress);
        DataManager manager=DataManager.getInstance(this);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                String email=etEmail.getText().toString().trim();
                String pass=etPassword.getText().toString().trim();

                if(!Constants.isValidEmail(email))
                {
                    Toast.makeText(RegisterActivity.this, "Please enter a valid email", Toast.LENGTH_SHORT).show();
                }
                else if(pass.length()<6)
                {
                    Toast.makeText(RegisterActivity.this, "Password must be 6 characters", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    User user=new User();
                    user.setEmail(email);
                    user.setPassword(pass);
                    user.setLightmode(false);
                    user.setNotification(true);
                    manager.setUserdetails(new Gson().toJson(user));
                    manager.setLoginstatus(true);
                    startActivity(new Intent(getBaseContext(),MainActivity.class));
                    Animatoo.INSTANCE.animateSlideLeft(RegisterActivity.this);
                    Toast.makeText(RegisterActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
                    finish();
                }

            }
        });
        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                finish();
                Animatoo.INSTANCE.animateSlideRight(RegisterActivity.this);
            }
        });
    }

}