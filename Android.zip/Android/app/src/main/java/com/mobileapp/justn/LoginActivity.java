package com.mobileapp.justn;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.blogspot.atifsoftwares.animatoolib.Animatoo;
import com.dd.CircularProgressButton;
import com.google.android.material.button.MaterialButton;
import com.google.gson.Gson;
import com.mobileapp.justn.data.DataManager;
import com.mobileapp.justn.model.User;
import com.mobileapp.justn.utils.Constants;

public class LoginActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        TextView tvRegister=findViewById(R.id.tv_register);
        DataManager manager=DataManager.getInstance(this);
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getBaseContext(),RegisterActivity.class));
                Animatoo.INSTANCE.animateSlideLeft(LoginActivity.this);
            }
        });

        EditText etEmail=findViewById(R.id.et_email);
        EditText etPassword=findViewById(R.id.et_pass);
        MaterialButton loginButton=findViewById(R.id.button_progress);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                String email=etEmail.getText().toString().trim();
                String pass=etPassword.getText().toString().trim();

                if(!Constants.isValidEmail(email))
                {
                    Toast.makeText(LoginActivity.this, "Please enter a valid email", Toast.LENGTH_SHORT).show();
                }
                else if(pass.length()<6)
                {
                    Toast.makeText(LoginActivity.this, "Password must be 6 characters", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    if(manager.getUserdetails().isEmpty())
                    {
                        Toast.makeText(LoginActivity.this, "No Record found", Toast.LENGTH_SHORT).show();
                    }
                    else
                    {
                        Gson gson=new Gson();
                        User data=gson.fromJson(manager.getUserdetails(),User.class);
                        if(data.getEmail().equalsIgnoreCase(email)&&data.getPassword().equalsIgnoreCase(pass))
                        {
                            manager.setLoginstatus(true);
                            startActivity(new Intent(getBaseContext(),MainActivity.class));
                            Animatoo.INSTANCE.animateSlideLeft(LoginActivity.this);
                        }
                        else
                        {
                            Toast.makeText(LoginActivity.this, "No Record found", Toast.LENGTH_SHORT).show();
                        }
                    }

                }

            }
        });

    }
}