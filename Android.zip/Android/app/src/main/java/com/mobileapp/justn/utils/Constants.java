package com.mobileapp.justn.utils;

import android.text.TextUtils;
import android.text.format.DateUtils;
import android.util.Patterns;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Constants
{
    public static boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }

    public static String getLastDatefordays(int days)
    {
        Calendar calendar=Calendar.getInstance();
        calendar.add(Calendar.DATE,-days);
        SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy-MM-DD");
        return dateFormat.format(calendar.getTimeInMillis());
    }

    public static String getDomains()
    {
        String domains="cnn.com,nytimes.com,washingtonpost.com,foxnews.com, bbc.com, msnbc.com," +
                "npr.org,abcnews.go.com,cbsnews.com,reuters.com,usatoday.com,politico.com,huffpost.com,bloomberg.com," +
                "apnews.com,theguardian.com,aljazeera.com,time.com,forbes.com,wsj.com,latimes.com,cnbc.com," +
                "huffpost.com,theatlantic.com,usatoday.com,independent.co.uk,buzzfeednews.com,vox.com," +
                "nationalgeographic.com,pbs.org,rollingstone.com,espn.com,newsweek.com,bostonglobe.com,cnbc.com," +
                "dallasnews.com,thehill.com,abcnews.go.com,npr.org,thedailybeast.com,bloomberg.com,theverge.com," +
                "nbcnews.com,businessinsider.com,usatoday.com";

        return domains;
    }

    public static String getFormattedDate(String val)
    {
        ZonedDateTime dateTime  = ZonedDateTime.parse(val);
        String formatted= DateTimeFormatter.ofPattern("dd-MM-yyyy  hh:mm a").format(dateTime);
        SimpleDateFormat inputFormat = new SimpleDateFormat("dd-MM-yyyy  hh:mm a");
        String str="";
        try
        {
            Date past = inputFormat.parse(formatted);
            Date now = new Date();
            long seconds= TimeUnit.MILLISECONDS.toSeconds(now.getTime() - past.getTime());
            long minutes=TimeUnit.MILLISECONDS.toMinutes(now.getTime() - past.getTime());
            long hours=TimeUnit.MILLISECONDS.toHours(now.getTime() - past.getTime());
            long days=TimeUnit.MILLISECONDS.toDays(now.getTime() - past.getTime());

            if(seconds<60)
            {
                str=seconds+" seconds ago";
            }
            else if(minutes<60)
            {
                str=minutes+" minutes ago";
            }
            else if(hours<24)
            {
                str=hours+" hours ago";
            }
            else
            {
                if(days==1)
                {
                    str="yesterday";
                }
                else
                {
                    str=days+" days ago";
                }
            }

            //str = DateUtils.getRelativeTimeSpanString(parsedDate.getTime() , Calendar.getInstance().getTimeInMillis(), DateUtils.MINUTE_IN_MILLIS).toString();
        }
        catch (ParseException e)
        {
            throw new RuntimeException(e);
        }

        return str;
    }
}
